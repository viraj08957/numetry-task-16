/* eslint-disable no-unused-vars */
import React from "react";
import DateTime from "./DateTime";

const NavBar = () => {
  return (
    <div className="navbar">
      <div className="container nav-flex">
        <DateTime />
      </div>
    </div>
  );
};

export default NavBar;
